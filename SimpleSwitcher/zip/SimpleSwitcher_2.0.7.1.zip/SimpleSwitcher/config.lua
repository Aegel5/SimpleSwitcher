-- User Config file
------------------------------------------------

-- Disable in specific program
disableInProgram = ""; -- example: "skype.exe,quake.exe"

-- Alternate mode settings
-- Try alternate mode if simpleswitcher not worked in program.
useAlternateModeByDefault = 0;  -- use for all program
useAlternateModeInProgram = ""; -- exmaple: "skype.exe,outlook.exe"

msDelayAfterCtrlC = 25; -- possible range [10-210]





