-- User Config file
------------------------------------------------

-- Disable in specific program
disableInProgram = ""; -- example: "skype.exe,quake.exe"

-- Alternate mode settings
-- Try alternate mode if simpleswitcher not worked in program.
useAlternateModeByDefault = 0;  -- use for all program
useAlternateModeInProgram = "pythonw.exe"; -- exmaple: "skype.exe,outlook.exe"

msDelayAfterCtrlC = 25; -- possible range [10-210]

-- Log level
ll = 0; -- 0 - no log, 1 - errors and basic info, 4 - max



-- Custome lang revert
CustomLang_List = "ru-RU, en-US";
CustomLang_RevertLastWorld = "";  -- Ex: Break
CustomLang_RevertCycle = "";      -- Ex: Shift+Break





